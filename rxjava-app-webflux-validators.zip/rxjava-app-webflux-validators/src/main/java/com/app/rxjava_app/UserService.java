package com.app.rxjava_app;

import javax.validation.constraints.AssertTrue;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class UserService {
	@AssertTrue
	public Mono<UserDTO> register(Mono<UserDTO> userDto){
		return userDto.doOnNext(System.out::println);
	}

}
