package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.CustomerDAO;
import com.dto.Customer;
import com.exception.CustomerNotFoundException;
import com.handler.CustomerHandler;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/cust")
public class CustController {
	
	@Autowired
	private CustomerDAO handler;
	
	@GetMapping("/{id}")
	public Mono<Customer> getCust(@PathVariable int id){
		  return handler.loadCust().filter(cust -> cust.getId() == id)
				  .next()
				  .switchIfEmpty(Mono.error(new CustomerNotFoundException("Book Not Found With ID :" +id)));
	}

}
