package com.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class AppException {
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<?> handleCustomerException(CustomerNotFoundException exception){
		Map<String, String> errorMap= new HashMap<String, String>();
		
		errorMap.put("error message", exception.getMessage());
		errorMap.put("status", HttpStatus.BAD_REQUEST.toString());
		return ResponseEntity.ok(errorMap);
	}

}
