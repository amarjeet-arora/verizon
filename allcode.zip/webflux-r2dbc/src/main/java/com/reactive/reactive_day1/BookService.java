package com.reactive.reactive_day1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class BookService {
	@Autowired
	BookRepo repo;
	
	public Mono<Book> saveBook(Book book){
		return repo.save(book);
	}
	public Flux<Book> loadBook(){
		return repo.findAll();
	}

}
