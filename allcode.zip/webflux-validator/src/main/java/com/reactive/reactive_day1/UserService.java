package com.reactive.reactive_day1;

import javax.validation.constraints.AssertTrue;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Mono;

@Service
public class UserService {

    @AssertTrue
    public Mono<UserDto> registerUser(Mono<UserDto> userDtoMono){
        return userDtoMono
                .doOnNext(System.out::println);
    }

}