package com.reactive.reactive_day1;

import lombok.Data;
import lombok.ToString;
import javax.validation.constraints.*;
@Data
@ToString
public class UserDto {

    private String firstName;

    @NotNull(message = "Last name can not be empty")
    private String lastName;

    @Min(value = 10, message = "{age.min.requirement}")
    @Max(value = 50, message = "Required max age is 50")
    private int age;

    @Pattern(regexp = "([a-z])+@([a-z])+\\.com", message = "Email should match the pattern a-z @ a-z .com")
    private String email;

}