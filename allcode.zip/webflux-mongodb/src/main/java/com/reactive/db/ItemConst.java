package com.reactive.db;

public class ItemConst {
	
	public static final String ITEM_END_POINT="/v1/items";

}
