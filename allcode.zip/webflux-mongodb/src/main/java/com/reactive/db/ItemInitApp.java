package com.reactive.db;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Flux;

@Component
public class ItemInitApp  implements CommandLineRunner{
	
	@Autowired
	ItemReactiveRepo repo;
	

	@Override
	public void run(String... args) throws Exception {
		 initialSetup();
		
	}
	
	public List<Item> data(){
		return Arrays.asList(new Item(null,"Samsung TV",4000.99),
				
				new Item("101","Iphone",400.99),
				new Item("102","earphones",40.9));
	}
	private void initialSetup(){
		repo.deleteAll()
		.thenMany(Flux.fromIterable(data()))
		.flatMap(repo ::save)
		.thenMany(repo.findAll())
		.subscribe((item -> {
			System.out.println("Item Inserted ...." +item);
		}));
	}

}
