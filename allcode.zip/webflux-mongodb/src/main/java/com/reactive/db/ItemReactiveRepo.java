package com.reactive.db;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import reactor.core.publisher.Mono;
@Repository
public interface ItemReactiveRepo extends ReactiveMongoRepository<Item, String>{
	
	Mono<Item> findByDescription(String description);

}
