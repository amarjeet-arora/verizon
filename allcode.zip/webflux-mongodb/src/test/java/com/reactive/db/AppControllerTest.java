package com.reactive.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.platform.commons.annotation.Testable;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.reactive.db.Item;
import com.reactive.db.ItemReactiveRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringRunner.class)
@DataMongoTest
public class AppControllerTest {
	
	@Autowired
	ItemReactiveRepo repo;

	
	
	
	
	List<Item> itemList= Arrays.asList(new Item(null,"Samsung TV",4000.99),
			
			new Item("101","Iphone",400.99),
			new Item("102","earphones",40.9));
	
	@Before
	public void setUp() {
		repo.deleteAll()
		.thenMany(Flux.fromIterable(itemList))
		.flatMap(repo ::save)
		.doOnNext((item -> {
			System.out.println("inserted");
		})).blockLast();
		 
	}
	@Test
	public void getAllItems() {
		StepVerifier.create(repo.findAll())
		.expectNextCount(3)
		.verifyComplete();
	}
	
	@Test
	public void getAllItemsById() {
		StepVerifier.create(repo.findById("102"))
		.expectNextMatches(item -> item.getDescription().equals("earphones"))
		.verifyComplete();
	}
	
	
	@Test
	public void saveData() {
		Item item= new Item(null, "Bose speakers", 889.99);
		Mono<Item> saved= repo.save(item);
		
		StepVerifier.create(saved.log("Saved Item :"))
		
		.expectNextMatches(item1 -> (item1.getDescription().equals("Bose speakers")))
		.verifyComplete();
	}
	
	
	 
}
