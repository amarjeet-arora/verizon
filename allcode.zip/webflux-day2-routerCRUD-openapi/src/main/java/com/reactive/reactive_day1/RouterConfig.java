package com.reactive.reactive_day1;

import org.springdoc.core.annotations.RouterOperation;
import org.springdoc.core.annotations.RouterOperations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.dto.Customer;
import com.handler.CustomerHandler;
import com.handler.CustomerStreamHandler;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@Configuration
public class RouterConfig {
	
	

	@Autowired
	private CustomerHandler handler;
	@Autowired
	private CustomerStreamHandler handler2;
	
	
	@Bean
	@RouterOperations(
			
			{
				@RouterOperation(path = "/router/customers",
						
						produces  ={
								MediaType.APPLICATION_JSON_VALUE
						},
						method = RequestMethod.GET,
						beanClass = CustomerHandler.class,
						beanMethod = "loadCustomers",
						operation = @Operation(
								operationId = "loadCustomers",
								responses = {
										@ApiResponse(
												responseCode = "200",
												description = "success oper",
												content = @Content(schema = @Schema(
														implementation = Customer.class
														))
												)
								}
								
								)
						
						
						),
				
				
				@RouterOperation(path = "/router/customer/{input}",
				
				produces  ={
						MediaType.APPLICATION_JSON_VALUE
				},
				method = RequestMethod.GET,
				beanClass = CustomerHandler.class,
				beanMethod = "findCustomer",
				operation = @Operation(
						operationId = "findCustomer",
						responses = {
								@ApiResponse(
										responseCode = "200",
										description = "success oper",
										content = @Content(schema = @Schema(
												implementation = Customer.class
												))
										),
								@ApiResponse(responseCode = "404",description = "Customer not found with given ID")
						},
						parameters = {
								@Parameter(in = ParameterIn.PATH,name="input")
						}
						
						)
				
				
				)
				
				
				
				
			}
			
			)
	
	public RouterFunction<ServerResponse> routerFunction(){
		
		return RouterFunctions.route()
				.GET("/router/customers",handler::loadCustomers)
				.GET("/router/customer/{input}",handler::findCustomer)
				.POST("/router/customer/save",handler::saveCustomer)
				.build();
	}
}
