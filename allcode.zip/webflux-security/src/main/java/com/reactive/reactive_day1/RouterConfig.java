package com.reactive.reactive_day1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.WebProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.handler.CustomerHandler;
import com.handler.CustomerStreamHandler;

@Configuration
public class RouterConfig {
	
	

	@Autowired
	private CustomerHandler handler;
	@Autowired
	private CustomerStreamHandler handler2;
	@Bean
	public WebProperties.Resources resources(){
		return new WebProperties.Resources();
	}
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction(){
		
		return RouterFunctions.route()
				.GET("/router/customers",handler::loadCustomers)
				.GET("/router/customer/{input}",handler::findCustomer)
				.POST("/router/customer/save",handler::saveCustomer)
				.build();
	}
	
	
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction2(){
		
		return RouterFunctions.route()
				.GET("/router1/demo",handler2::getCustomers)
				.GET("/router1/demo/{input}",handler::findCustomer)
				 
				.build();
	}
	
	
	@Bean
	public RouterFunction<ServerResponse> routerFunction3(){
		
		return RouterFunctions.route()
				.GET("/router2/customers2/stream",handler2::getCustomers)
				.GET("/router2/customers2/{input}",handler::findCustomer)
				 
				.build();
	}
	
	
	
	
}
