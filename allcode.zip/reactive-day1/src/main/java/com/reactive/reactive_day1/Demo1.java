package com.reactive.reactive_day1;

import java.util.Arrays;
import java.util.List;

import io.reactivex.Emitter;
import io.reactivex.Observable;

public class Demo1 {
	
	
	public static void main(String[] args) {
		createOption3();
		
	}

	private static void createOption1() {
		// using just
		
		Observable<Integer> observable= Observable.just(10,120,30,40,50);
		observable.subscribe(item -> System.out.println(item));
		
	}
	
	private static void createOption2() {
		// using just
		List<Integer> list = Arrays.asList(10,120,30,40,50);
		
		Observable<Integer> observable= Observable.fromIterable(list);
		observable.subscribe(item -> System.out.println(item));
		
	}
	
	
	private static void createOption3() {
		// using just
		 
		
		Observable<Integer> observable= Observable.create(emitter -> {
			emitter.onNext(10);
			emitter.onNext(20);
			emitter.onNext(30);
			emitter.onNext(40);
			emitter.onNext(null);
			emitter.onComplete();
		});
		observable.subscribe(item -> System.out.println(item),
				error -> System.out.println("Something went wrong....  " +error.getLocalizedMessage())
				,()->System.out.println("Completed data")
				);
		
	}
	
}
