package com.reactive.reactive_day1;

import io.reactivex.Observable;
import io.reactivex.observables.ConnectableObservable;

public class Demo2 {
	
	public static void main(String[] args) {
	hotObs();
	}
	// default observer is COLD
	private static void coldObs() {
		Observable<Integer> observable= Observable.just(10,20,30,40,50);
		
		//first subs
		observable.subscribe(item -> System.out.println(item));
		
		pause(3000);
		// second 
		observable.subscribe(item -> System.out.println(item));
		
	}

	private static void hotObs() {
		ConnectableObservable<Integer> observable= Observable.just(10,20,30,40,50).publish();
		
		//first subs
		
		observable.subscribe(item -> System.out.println("data-first" +item));
		observable.connect();
		observable.subscribe(item -> System.out.println("data2" +item));
		//observable.connect();
		
	}

	
	
	
	private static void pause(int duration) {
		try {
			Thread.sleep(duration);
		}catch (Exception e) {
			 e.printStackTrace();
		}
	}
}
