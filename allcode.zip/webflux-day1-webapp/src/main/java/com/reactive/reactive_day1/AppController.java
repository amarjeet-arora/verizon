package com.reactive.reactive_day1;

import java.time.Duration;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/verizon")
public class AppController {

	@GetMapping("/flux")
	public Flux<Integer> returnFlux(){
		return Flux.just(1,2,3,4).log();
	}
	
	@GetMapping(value="/flux2",produces=MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Integer> returnFlux2(){
		return Flux.just(1,2,3,4).delayElements(Duration.ofSeconds(1)).log();
	}
	
}
