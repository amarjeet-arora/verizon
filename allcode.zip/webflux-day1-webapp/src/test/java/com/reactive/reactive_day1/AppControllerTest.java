package com.reactive.reactive_day1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.platform.commons.annotation.Testable;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@RunWith(SpringRunner.class)
@WebFluxTest
public class AppControllerTest {

	@Autowired
	WebTestClient testClient;
	
	//@Test
	public void fluxTest1() {
		
		Flux<Integer> fluxInt= testClient.get().uri("/flux")
				.exchange()
				.expectStatus().isOk()
				.returnResult(Integer.class)
				.getResponseBody();
		
		StepVerifier.create(fluxInt)
		.expectSubscription()
		.expectNext(1)
		.expectNext(2)
		.expectNext(3)
		.expectNext(4)
		.verifyComplete();
		
		
	}
	
	
	@Test
	public void fluxTest2() {
		List<Integer> expectIntegerList= Arrays.asList(1,2,3);
		EntityExchangeResult<List<Integer>> entityExchangeResult= 
				testClient.get().uri("/flux")
				.exchange()
				.expectStatus().isOk()
				 .expectBodyList(Integer.class)
				 .returnResult();
		
		 assertEquals(expectIntegerList, entityExchangeResult.getResponseBody());
		
	}
}
