package com.reactive.db;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Flux;

@RestController
 
public class AppController {
	
	 
WebClient client= WebClient.create("http://localhost:8080");


@GetMapping("/client/loaddata")
public Flux<Item> getAll(){
	return  client.get().uri("/v1/items")
			.retrieve()
			.bodyToFlux(Item.class)
			.log("Item data loaded..... !");
}
	 
	
}
