package com.reactive.reactive_day1;

import java.util.Arrays;
import java.util.List;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class DemoApp {

	
	public Flux<String> fluxApp() {
		List<String> list = Arrays.asList("alex","surya","Amarjeet"); // db or remote service
		//return Flux.just("alex","surya","Mannoj");
		return Flux.fromIterable(list).log();
	}
	
	
	public Flux<String> fluxAppFilter(int strlngth) {
		List<String> list = Arrays.asList("alex","surya","Amarjeet"); // db or remote service
		//return Flux.just("alex","surya","Mannoj");
		return Flux.fromIterable(list).map(s ->s.toUpperCase()).
				filter(s ->s.length() > strlngth).log();
	}
	
	
	
	
	public Flux<String> fluxAppMap() {
		List<String> list = Arrays.asList("alex","surya","Mannoj"); // db or remote service
		 
		  //return Flux.fromIterable(list).map(String :: toUpperCase).log();
		   return Flux.fromIterable(list).map(s ->s.toUpperCase()).log();
	}
	public Mono<String> monoApp() {
		 
		return Mono.just("Sameer");
	}
	public static void main(String[] args) {
		DemoApp app= new DemoApp();
		
		app.fluxApp().subscribe(name -> {
			System.out.println("Flux Name is " + name);
		});
		app.monoApp().subscribe(name -> {
			System.out.println("Mono Name is " + name);
		});
	}
	
	
	public Flux<String> fluxFlatMap(int strlngth) {
		List<String> list = Arrays.asList("alex","surya","Mannoj"); 
		 
		   
		   return Flux.fromIterable(list).map(s ->s.toUpperCase()).
				   filter(s ->s.length() > strlngth)
				   .flatMap(s ->splitString(s)) //A,L,E,X,S,u,r,y,a
				   .log();
	}
	
	public Flux<String> splitString(String name){
		 
		 return Flux.fromArray(name.split(""));
		
	}
	
	
}
