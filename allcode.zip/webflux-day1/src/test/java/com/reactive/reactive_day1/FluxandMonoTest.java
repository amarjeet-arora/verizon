package com.reactive.reactive_day1;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

public class FluxandMonoTest {
	
	DemoApp app= new DemoApp();
	
	
	//@Test
	void testFlux() {
		//given
		
		//when
		Flux< String> namesdata= app.fluxApp();
		
		
		//then
		StepVerifier.create(namesdata)
		.expectNext("surya")
		.expectNextCount(2)
		.verifyComplete();
	}
	//@Test
	void testFluxMap() {
		//given
		
		//when
		Flux< String> namesdata= app.fluxApp();
		
		
		//then
		StepVerifier.create(namesdata)
		.expectNext("surya")
		.expectNextCount(2)
		.verifyComplete();
	}
	@Test
	void testFluxMapFilter() {
		//given
		int len=4;
		//when
		Flux< String> namesdata= app.fluxAppFilter(len);
		
		
		//then
		StepVerifier.create(namesdata)
		.expectNext("SURYA","AMARJEET")
		 
		.verifyComplete();
	}
	
	
	
	
	

}
