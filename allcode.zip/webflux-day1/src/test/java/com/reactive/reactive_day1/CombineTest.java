package com.reactive.reactive_day1;

import java.time.Duration;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

public class CombineTest {
	
	//@Test
	void test1() {
	
	Flux<String> flux1= Flux.just("A","B","C");
	Flux<String> flux2= Flux.just("D","E","F");
	
	
	Flux<String> mergedString=  Flux.merge(flux1,flux2);
	
	StepVerifier.create(mergedString.log())
	.expectNext("A","B","C","D","E","F")
	.verifyComplete();
	}
	//@Test
	void test2() {
	
	Flux<String> flux1= Flux.just("A","B","C").delayElements(Duration.ofSeconds(1));
	Flux<String> flux2= Flux.just("D","E","F").delayElements(Duration.ofSeconds(1));
	
	
	Flux<String> mergedString=  Flux.merge(flux1,flux2);
	
	StepVerifier.create(mergedString.log())
	//.expectNext("A","B","C","D","E","F")
	.expectNextCount(6)
	.verifyComplete();
	}
	@Test
	void test3() {
	
	Flux<String> flux1= Flux.just("A","B","C").delayElements(Duration.ofSeconds(1));
	Flux<String> flux2= Flux.just("D","E","F").delayElements(Duration.ofSeconds(1));
	
	
	Flux<String> mergedString=  Flux.concat(flux1,flux2);
	
	StepVerifier.create(mergedString.log())
	.expectNext("A","B","C","D","E","F")
	//.expectNextCount(6)
	.verifyComplete();
	}
}
